package com.hitss.springboot.dependencia_app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DependenciaAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
