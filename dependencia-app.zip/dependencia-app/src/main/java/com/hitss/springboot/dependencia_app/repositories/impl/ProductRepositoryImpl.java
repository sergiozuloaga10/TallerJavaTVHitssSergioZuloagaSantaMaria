package com.hitss.springboot.dependencia_app.repositories.impl;

import java.util.List;

import com.hitss.springboot.dependencia_app.models.Product;
import com.hitss.springboot.dependencia_app.repositories.ProductRepository;

public class ProductRepositoryImpl implements ProductRepository {

    private List<Product> products;
    @Override
    public List<Product> findAll() {
        // TODO Auto-generated method stub
        return products;
    }

    @Override
    public Product findById(Long id) {
        // TODO Auto-generated method stub
        return products.stream().filter(p -> p.getId().equals(id))
                        .findFirst()
                        .orElse(null);
    }
    
}
